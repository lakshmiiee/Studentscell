
<html>
<head>
<meta charset="utf-8">
<title>View Records</title>
<link rel="stylesheet" href="css/style.css" />
</head>
<body>
<div class="form">
<p><a href="admin_view.php">Home</a> 
| <a href="admin_logout.php">Logout</a></p>
<h2>View Records</h2>
<table width="100%" border="1" style="border-collapse:collapse;">
<thead>
<tr>
<th><strong>Name</strong></th>
<th><strong>Gender</strong></th>
<th><strong>Username</strong></th>
<th>Salary</th>
<th><strong>Changed Amount</strong></th>
<th><strong>Phone</strong></th>
<th>Proceed</th>

</tr>
</thead>
<tbody>
<?php
$objConnect = mysql_connect("localhost","grapeste_root","gopi1234") or die("connection error".mysql_error());
	$objDB = mysql_select_db("grapeste_mydatabase") or die("error in selection".mysql_error());

$count=1;


session_start();
//$objConnect = mysqli_connect("localhost","root","","satdb") or die("connection error".mysqli_error());
	//$objDB = mysql_select_db("satdb") or die("error in selection".mysql_error());

	
$n="approved";
$sql="select * from csr_register";
	$result=mysql_query($sql) or die('error in selection'.mysql_error());
	while($line=mysql_fetch_array($result))
	{
		 ?>
<tr>
<td align="center"><?php echo $line['name'] ?></td>
<td align="center"><?php echo $line['gender'] ?></td>
<td align="center"><?php echo $line['username'] ?></td>
<td align="center"><?php echo $line['salary'] ?></td>
<td align="center"><?php echo $line['amtdonate'] ?></td>
<td align="center"><?php echo $line['phone'] ?></td>

<td align="center">
<a href="admin_approve1.php?id=<?php echo $line["app_no"]; ?>">Approve</a>
</td>

</tr>

<?php $count++; } ?>
</tbody>
</table>

</div>
</body>
</html>




