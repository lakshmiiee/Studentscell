<html>
    <body>
        <?php
        session_start();
        include("connection.php");
// $objConnect = mysql_connect("localhost","grapeste_root","gopi1234") or die("connection error".mysql_error());
	$objDB = mysql_select_db("studentscell") or die("error in selection".mysql_error());

$myusername=$_POST["myusername"];
$mypassword=$_POST["mypassword"];
session_start();


//or die("error in selection".mysql_error());

if($myusername=="admin" && $mypassword=="admin") {
?>

<script language="javascript">alert('Login Success');window.location.replace('admin_index.php');</script>

<?php
echo "password accepted";
            $_SESSION['login']=true;

        }else {
?>
<script>
    alert("Invalid admin username and password");
    window.location.replace('admin_loginpage.php');
</script>
<?php
        }
        ?>

    </body>
</html>



