This folder contains JavaScript.
