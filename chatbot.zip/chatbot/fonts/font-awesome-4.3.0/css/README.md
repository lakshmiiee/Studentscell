Required stylesheet for font awesome
