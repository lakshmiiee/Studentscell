Font Awesome used
