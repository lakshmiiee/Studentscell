This folder contains the fonts used.
