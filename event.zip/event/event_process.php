<?php
include "db_connect.php";
$title=$_POST['title'];
$sdate=$_POST['sdate'];
$edate=$_POST['edate'];
$created=$_POST['created'];
$status=$_POST['status'];
$query="insert into events(title,start_date,end_date,created,status)values('$title','$sdate','$edate','$created','$status')";
$res=mysqli_query($conn,$query) or die(mysqli_error($conn));
 
if($res){
        ?>
        <script language="javascript">alert('upload success');window.location.replace('index.php'); </script>
        <?php
}
    else{
   
        ?>
        <script language="javascript">alert('upload failed');window.location.replace('admin_add_book.php'); </script>
        <?php 
    }

